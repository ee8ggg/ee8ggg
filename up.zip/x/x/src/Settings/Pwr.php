<?php

declare(strict_types=1);

namespace danog\MadelineProto\Settings;

use danog\MadelineProto\SettingsAbstract;

/**
 * PWRTelegram settings.
 */
final class Pwr extends SettingsAbstract
{
}
