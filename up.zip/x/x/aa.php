<?php
date_default_timezone_set("Asia/Baghdad");
if (file_exists('madeline.php')){
    require_once 'madeline.php';
}
define('MADELINE_BRANCH', 'deprecated');
function bot($method, $datas = []){
    $token = file_get_contents("token");
    $url = "https://api.telegram.org/bot$token/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}
$settings['app_info']['api_id'] = 13167118;
$settings['app_info']['api_hash'] = '6927e2eb3bfcd393358f0996811441fd';
$settings['full'] = true;
$settings['TURBO_ENGINE'] = \danog\MadelineProto\RPC\Socket\Engine\Event::class;
$settings['TURBO_ENGINE_POLL'] = true;
$settings['fast_mode'] = true;
$settings['process_count'] = 4;
$settings['max_requests_per_child'] = 1000;
$settings['trace'] = true;
$settings['connection']['timeout'] = 10;
$settings['connection']['max_tries'] = 5;
$MadelineProto = new \danog\MadelineProto\API('a.madeline',$settings);
$MadelineProto->start();
$info = json_decode(file_get_contents('info.json'),true);
$num = $info["number1"];
$x= file_get_contents('xa');
do{
file_put_contents('xa',$x++);
$info = json_decode(file_get_contents('in.json'),true);
$info["loop1"] = $x;
file_put_contents('in.json', json_encode($info));
$users = explode("\n",file_get_contents("users"));
foreach($users as $user){
    $kd = strlen($user);
    if($user != ""){
    try{$MadelineProto->messages->getPeerDialogs(['peers' => [$user]]);
        $x++;
    }catch (\danog\MadelineProto\Exception | \danog\MadelineProto\RPCErrorException $e) {
                try{$MadelineProto->account->updateUsername(['username'=>$user]);
                    bot('sendvideo', ['video' =>'https://t.me/Lucianohiting/2', 'chat_id' => file_get_contents("ID"), 'caption' => "- 𝒊 𝒉𝒊𝒕 𝒐𝒏𝒆 !\n- 𝒖𝒔𝒆𝒓𝒏𝒂𝒎𝒆 : 「 @$user 」\n- 𝒄𝒍𝒊𝒄𝒌𝒔 : 「 $x 」\n- 𝒔𝒂𝒗𝒆 : 「Account 」"]);
                bot('sendMessage', ['chat_id' => file_get_contents("ID"), 'text' => "𝒊𝒔 𝒄𝒉𝒆𝒄𝒌𝒆𝒓 #1",]);
                    $data = str_replace("\n".$user,"", file_get_contents("users"));
                    file_put_contents("users", $data);
                }catch(Exception $e){
                    echo $e->getMessage();
                    if($e->getMessage() == "USERNAME_INVALID"){
                        bot('sendMessage', ['chat_id' => file_get_contents("ID"), 'text' => "╭ checker ❲ 1 ❳  \n | username is Band\n╰ Done Delet on list ↣ @$user",]);
                        $data = str_replace("\n".$user,"", file_get_contents("users"));
                        file_put_contents("users", $data);
                    }elseif($e->getMessage() == "This peer is not present in the internal peer database"){
                        $MadelineProto->account->updateUsername(['username'=>$user]);
                    }elseif($e->getMessage() == "USERNAME_OCCUPIED"){
                        bot('sendMessage', ['chat_id' => file_get_contents("ID"), 'text' => "╭ checker ❲ 1 ❳ 🛎 \n | username not save\n╰ FLood 1500 ↣ @$user",]);
                        $data = str_replace("\n".$user,"", file_get_contents("users"));
                        file_put_contents("users", $data);
                    }else{
                        bot('sendMessage', ['chat_id' => file_get_contents("ID"), 'text' =>  "1 • Error @$user ".$e->getMessage()]);
                        $info = json_decode(file_get_contents('info.json'),true);
                        $info["num1"] = "delet";file_put_contents('info.json', json_encode($info));
                    }     
                }
            }
        } 
    }
  }while(1);